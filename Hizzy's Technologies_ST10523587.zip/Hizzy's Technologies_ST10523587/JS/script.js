// script.js
document.addEventListener('DOMContentLoaded', () => {
    
    // 1. Contact Form Validation
    const contactForm = document.querySelector('.contact-form form');
    if (contactForm) {
        contactForm.addEventListener('submit', (e) => {
            const name = document.getElementById('name')?.value.trim();
            const email = document.getElementById('email')?.value.trim();
            const message = document.getElementById('message')?.value.trim();

            if (!name || !email || !message) {
                e.preventDefault();
                alert("Please fill in all required fields.");
                return;
            }
            if (!validateEmail(email)) {
                e.preventDefault();
                alert("Please enter a valid email address.");
                return;
            }
            alert("Thank you, " + name + "! Your message has been sent.");
        });
    }

    // 2. Shopping Cart Logic
    const cartButtons = document.querySelectorAll('.add-to-cart-btn');

    cartButtons.forEach(button => {
        button.addEventListener('click', (e) => {
            e.preventDefault();
            const productName = button.getAttribute('data-name');
            alert(productName + " has been added to your cart!");
        });
    });

    // Product Search/Filter Logic
    const searchInput = document.getElementById('product-search');
    if (searchInput) {
        searchInput.addEventListener('input', (e) => {
            const filter = e.target.value.toLowerCase();
            const products = document.querySelectorAll('.product-item');

            products.forEach(product => {
                const title = product.querySelector('h3').innerText.toLowerCase();
                product.style.display = title.includes(filter) ? '' : 'none';
            });
        });
    }
});